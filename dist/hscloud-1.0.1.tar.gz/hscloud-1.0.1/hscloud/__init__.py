# -----------------------------------------------------------
# Library to login to Dreo cloud and get device info.
#
# (C) 2024 kane wang
# Released under MIT License
# email app@hesung.com
# -----------------------------------------------------------